 <script src="https://code.jquery.com/jquery-2.2.0.min.js"></script>
<script src="https://www.gstatic.com/firebasejs/5.7.2/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyAaCy_vA0LxhEaP3lTFjBU5-TiUI3Tq934",
    authDomain: "group-project-5356f.firebaseapp.com",
    databaseURL: "https://group-project-5356f.firebaseio.com",
    projectId: "group-project-5356f",
    storageBucket: "group-project-5356f.appspot.com",
    messagingSenderId: "319879909553"
  };
  firebase.initializeApp(config);
 
 var CITDrivers = document.getElementById('CITDrivers');
  var dbRef = firebase.database().ref().child('vehicleLocations/id1/Model');
  dbRef.on('value', snap => CITDrivers.innerText = snap.val());
  
  var CITDrivers2 = document.getElementById('CITDrivers2');
  var dbRef = firebase.database().ref().child('vehicleLocations/id2/Model');
  dbRef.on('value', snap => CITDrivers2.innerText = snap.val());
  
  var CITDrivers3 = document.getElementById('CITDrivers3');
  var dbRef = firebase.database().ref().child('vehicleLocations/id3/Model');
  dbRef.on('value', snap => CITDrivers3.innerText = snap.val());
  
  var vehicleWhereabouts = document.getElementById('vehicleWhereabouts');
  var dbRef = firebase.database().ref().child('vehicleLocations/id1/GPS/Lat');
  dbRef.on('value', snap => vehicleWhereabouts.innerText = snap.val());

// Reference to the carNew object in your Firebase database
var carNew = firebase.database().ref("carNew");

// Save a new recommendation to the database, using the input in the form
var submitVehicle = function () {

  // Get input values from each of the form elements
  var carBrand = $("#talkcarBrand").val();
  var regPlate = $("#talkregPlate").val();

  // Push a new recommendation to the database using those values
  carNew.push({
    "carBrand": carBrand,
    "regPlate": regPlate,
  });
};

// When the window is fully loaded, call this function.
// Note: because we are attaching an event listener to a particular HTML element
// in this function, we can't do that until the HTML element in question has
// been loaded. Otherwise, we're attaching our listener to nothing, and no code
// will run when the submit button is clicked.
$(window).load(function () {

  // Find the HTML element with the id carForm, and when the submit
  // event is triggered on that element, call submitVehicle.
  $("#carForm").submit(submitVehicle);

});
  
</script>